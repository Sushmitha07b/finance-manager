<?php
// Include the database connection
include 'db_connection.php';

// SQL query to get all transactions
$sql = "SELECT * FROM transactions ORDER BY date DESC";
$result = $conn->query($sql);

// Fetch all transactions
$transactions = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    echo json_encode($transactions);
} else {
    echo json_encode(["message" => "No transactions found"]);
}

// Close the connection
$conn->close();
?>
