// Mock data for Income and Expense (can be updated dynamically from backend later)
const incomeData = [500, 1500, 3000, 1000, 4000];
const expenseData = [400, 800, 200, 1500, 700];

// Calculate totals
const totalIncome = incomeData.reduce((sum, val) => sum + val, 0);
const totalExpenses = expenseData.reduce((sum, val) => sum + val, 0);
const balance = totalIncome - totalExpenses;

// Update the dashboard values
document.getElementById('total-income').innerText = `$${totalIncome}`;
document.getElementById('total-expenses').innerText = `$${totalExpenses}`;
document.getElementById('balance').innerText = `$${balance}`;

// Chart for Income
const incomeCtx = document.getElementById('income-chart').getContext('2d');
new Chart(incomeCtx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [{
            label: 'Income',
            data: incomeData,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Chart for Expenses
const expenseCtx = document.getElementById('expense-chart').getContext('2d');
new Chart(expenseCtx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [{
            label: 'Expenses',
            data: expenseData,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
