document.getElementById('transactionForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent the form from submitting the traditional way

    // Get form data
    let formData = new FormData(this);

    // Use Fetch API to send data to backend PHP file
    fetch('http://localhost/finance_manager/add_transaction.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json()) // Parse JSON response
    .then(data => {
        // Display success or error message
        const messageDiv = document.getElementById('message');
        if (data.status === 'success') {
            messageDiv.innerHTML = `<p style="color:green;">${data.message}</p>`;
        } else {
            messageDiv.innerHTML = `<p style="color:red;">Error: ${data.message}</p>`;
        }
    })
    .catch(error => console.error('Error:', error)); // Log any errors
});
