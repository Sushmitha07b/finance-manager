<?php
// Include the database connection
include 'db_connection.php';

// Retrieve transaction ID from the POST request
$transaction_id = $_POST['id'];

// SQL query to delete the transaction
$sql = "DELETE FROM transactions WHERE id = $transaction_id";

// Execute the query and return response
if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Transaction deleted successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error: " . $conn->error]);
}

// Close the connection
$conn->close();
?>
