<?php
// Include the database connection
include 'db_connection.php';

// Fetch the report type from the GET request ("monthly" or "annual")
$type = $_GET['type'];

// SQL query based on report type
if ($type === "monthly") {
    $sql = "SELECT type, category, SUM(amount) as total, MONTH(date) as month
            FROM transactions
            WHERE YEAR(date) = YEAR(CURDATE())
            GROUP BY type, category, month";
} else if ($type === "annual") {
    $sql = "SELECT type, category, SUM(amount) as total, YEAR(date) as year
            FROM transactions
            GROUP BY type, category, year";
}

// Execute the query
$result = $conn->query($sql);

// Prepare the data
$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode(["message" => "No records found"]);
}

// Close the connection
$conn->close();
?>
