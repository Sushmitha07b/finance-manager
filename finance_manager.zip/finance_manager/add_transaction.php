<?php
// Include database connection
include 'db_connection.php';

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from the POST request
    $amount = $_POST['amount'];
    $type = $_POST['type'];
    $category = $_POST['category'];
    $date = $_POST['date'];
    $description = $_POST['description'];

    // Ensure all variables have values and are not null
    if (!empty($amount) && !empty($type) && !empty($category) && !empty($date)) {
        // Prepare the SQL query to insert the transaction
        $sql = "INSERT INTO transactions (amount, type, category, date, description) 
                VALUES ('$amount', '$type', '$category', '$date', '$description')";

        // Execute the query and check for success
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Transaction added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
