<?php
// Include database connection
include 'db_connection.php';

// Get the report type (monthly or yearly) from the request
$reportType = $_GET['report_type']; // 'monthly' or 'yearly'

// Initialize SQL query
if ($reportType == 'monthly') {
    // Monthly report: Group transactions by month and year
    $sql = "SELECT 
                DATE_FORMAT(date, '%Y-%m') AS month, 
                SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) AS total_income,
                SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) AS total_expenses
            FROM transactions
            GROUP BY DATE_FORMAT(date, '%Y-%m')";
} else {
    // Yearly report: Group transactions by year
    $sql = "SELECT 
                DATE_FORMAT(date, '%Y') AS year, 
                SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) AS total_income,
                SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) AS total_expenses
            FROM transactions
            GROUP BY DATE_FORMAT(date, '%Y')";
}

$result = $conn->query($sql);
$report = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $report[] = $row;
    }
    echo json_encode($report);
} else {
    echo json_encode([]);
}
?>
